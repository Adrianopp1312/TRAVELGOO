import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { HomePage } from './home.page';

describe('HomePage', () => {
  let component: HomePage;
  let fixture: ComponentFixture<HomePage>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [HomePage],
      providers: [provideRouter([])]
    }).compileComponents();

    fixture = TestBed.createComponent(HomePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have title TravelGo', () => {
    const compiled = fixture.nativeElement;
    expect(compiled.querySelector('ion-title')).toBeTruthy();
  });

  it('should navigate to destinos', () => {
    spyOn(component, 'goToDestinos');
    component.goToDestinos();
    expect(component.goToDestinos).toHaveBeenCalled();
  });

  it('should navigate to contacto', () => {
    spyOn(component, 'goToContacto');
    component.goToContacto();
    expect(component.goToContacto).toHaveBeenCalled();
  });
});
