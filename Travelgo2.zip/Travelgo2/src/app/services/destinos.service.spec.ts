import { TestBed } from '@angular/core/testing';
import { DestinosService } from './destinos.service';

describe('DestinosService', () => {
  let service: DestinosService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DestinosService]
    });
    service = TestBed.inject(DestinosService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should have getDestinos method', () => {
    expect(service.getDestinos).toBeDefined();
  });

  it('should have addDestino method', () => {
    expect(service.addDestino).toBeDefined();
  });

  it('should have updateDestino method', () => {
    expect(service.updateDestino).toBeDefined();
  });

  it('should have deleteDestino method', () => {
    expect(service.deleteDestino).toBeDefined();
  });
});
