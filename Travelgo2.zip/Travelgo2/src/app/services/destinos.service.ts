import { Injectable, inject } from '@angular/core';
import { 
  Firestore, 
  collection, 
  collectionData, 
  doc, 
  addDoc, 
  updateDoc, 
  deleteDoc,
  query,
  orderBy
} from '@angular/fire/firestore';
import { Observable } from 'rxjs';
import { Destino } from '../models/models';

@Injectable({
  providedIn: 'root'
})
export class DestinosService {
  private firestore = inject(Firestore);
  private collectionName = 'destinos';

  // Obtener todos los destinos
  getDestinos(): Observable<Destino[]> {
    const destinosRef = collection(this.firestore, this.collectionName);
    return collectionData(destinosRef, { idField: 'id' }) as Observable<Destino[]>;
  }

  // Agregar un destino
  async addDestino(destino: Destino): Promise<void> {
    const destinosRef = collection(this.firestore, this.collectionName);
    await addDoc(destinosRef, destino);
  }

  // Actualizar un destino
  async updateDestino(id: string, destino: Partial<Destino>): Promise<void> {
    const destinoRef = doc(this.firestore, this.collectionName, id);
    await updateDoc(destinoRef, destino);
  }

  // Eliminar un destino
  async deleteDestino(id: string): Promise<void> {
    const destinoRef = doc(this.firestore, this.collectionName, id);
    await deleteDoc(destinoRef);
  }
}
