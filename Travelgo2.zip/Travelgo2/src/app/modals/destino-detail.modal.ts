import { Component, Input, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonButton,
  IonIcon,
  IonButtons,
  IonChip,
  IonLabel,
  ModalController,
  ToastController
} from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import {
  closeOutline,
  heartOutline,
  heart,
  shareOutline,
  locationOutline,
  navigateOutline,
  airplaneOutline,
  calendarOutline,
  walletOutline,
  sunnyOutline,
  languageOutline,
  cashOutline,
  starOutline,
  mapOutline
} from 'ionicons/icons';
import { Destino } from '../models/models';
import { FavoritosService } from '../services/favoritos.service';

@Component({
  selector: 'app-destino-detail-modal',
  template: `
    <ion-header>
      <ion-toolbar>
        <ion-title>{{ destino.nombre }}</ion-title>
        <ion-buttons slot="end">
          <ion-button (click)="dismiss()">
            <ion-icon name="close-outline"></ion-icon>
          </ion-button>
        </ion-buttons>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding">
      <div class="modal-content tg-slide-up">
        <!-- Imagen principal -->
        <div class="image-container">
          <img [src]="destino.imagen" [alt]="destino.nombre"
               onerror="this.src='https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=800'"/>
          <div class="image-actions">
            <ion-button fill="clear" (click)="toggleFavorite()">
              <ion-icon [name]="isFavorite ? 'heart' : 'heart-outline'" 
                        [class.is-favorite]="isFavorite"></ion-icon>
            </ion-button>
            <ion-button fill="clear" (click)="share()">
              <ion-icon name="share-outline"></ion-icon>
            </ion-button>
          </div>
          <div class="country-badge">
            <ion-icon name="navigate-outline"></ion-icon>
            {{ destino.pais }}
          </div>
        </div>

        <!-- Información del destino -->
        <div class="destino-info">
          <div class="destino-header">
            <h1>{{ destino.nombre }}</h1>
            <ion-chip class="continent-chip" *ngIf="destino.continente">
              <ion-icon name="map-outline"></ion-icon>
              <ion-label>{{ destino.continente }}</ion-label>
            </ion-chip>
          </div>

          <p class="description">{{ destino.descripcion }}</p>

          <!-- Información detallada -->
          <div class="info-grid">
            <div class="info-item" *ngIf="destino.idioma">
              <ion-icon name="language-outline"></ion-icon>
              <div class="info-content">
                <span class="info-label">Idioma</span>
                <span class="info-value">{{ destino.idioma }}</span>
              </div>
            </div>
            
            <div class="info-item" *ngIf="destino.moneda">
              <ion-icon name="cash-outline"></ion-icon>
              <div class="info-content">
                <span class="info-label">Moneda</span>
                <span class="info-value">{{ destino.moneda }}</span>
              </div>
            </div>
            
            <div class="info-item" *ngIf="destino.clima">
              <ion-icon name="sunny-outline"></ion-icon>
              <div class="info-content">
                <span class="info-label">Clima</span>
                <span class="info-value">{{ destino.clima }}</span>
              </div>
            </div>
            
            <div class="info-item" *ngIf="destino.mejorEpoca">
              <ion-icon name="calendar-outline"></ion-icon>
              <div class="info-content">
                <span class="info-label">Mejor época</span>
                <span class="info-value">{{ destino.mejorEpoca }}</span>
              </div>
            </div>

            <div class="info-item" *ngIf="destino.precio">
              <ion-icon name="wallet-outline"></ion-icon>
              <div class="info-content">
                <span class="info-label">Desde</span>
                <span class="info-value price">\${{ destino.precio }} USD</span>
              </div>
            </div>
          </div>

          <!-- Atracciones -->
          <div class="atracciones-section" *ngIf="destino.atracciones">
            <h3><ion-icon name="star-outline"></ion-icon> Atracciones principales</h3>
            <p>{{ destino.atracciones }}</p>
          </div>

          <!-- Botones de acción -->
          <div class="action-buttons">
            <ion-button expand="block" class="tg-btn-primary" (click)="reservar()">
              Reservar Ahora
            </ion-button>
            <ion-button expand="block" fill="outline" (click)="verPaquetes()">
              Ver Paquetes Relacionados
            </ion-button>
          </div>
        </div>
      </div>
    </ion-content>
  `,
  styles: [`
    .modal-content {
      padding-bottom: 40px;
    }

    .image-container {
      position: relative;
      width: 100%;
      height: 280px;
      border-radius: 20px;
      overflow: hidden;
      margin-bottom: 24px;

      img {
        width: 100%;
        height: 100%;
        object-fit: cover;
      }

      .image-actions {
        position: absolute;
        top: 12px;
        right: 12px;
        display: flex;
        gap: 8px;

        ion-button {
          --background: rgba(255, 255, 255, 0.9);
          --border-radius: 50%;
          width: 44px;
          height: 44px;

          ion-icon {
            font-size: 24px;
            color: #2c3e50;

            &.is-favorite {
              color: #e74c3c;
            }
          }
        }
      }

      .country-badge {
        position: absolute;
        bottom: 12px;
        left: 12px;
        background: rgba(255, 255, 255, 0.95);
        padding: 8px 16px;
        border-radius: 20px;
        font-weight: 600;
        color: #1a5276;
        display: flex;
        align-items: center;
        gap: 6px;

        ion-icon {
          font-size: 18px;
        }
      }
    }

    .destino-info {
      .destino-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        margin-bottom: 16px;
        flex-wrap: wrap;
        gap: 12px;

        h1 {
          font-size: 28px;
          font-weight: 700;
          color: #2c3e50;
          margin: 0;
        }

        .continent-chip {
          --background: rgba(243, 156, 18, 0.15);
          --color: #f39c12;
          font-weight: 500;
        }
      }

      .description {
        font-size: 16px;
        color: #7f8c8d;
        line-height: 1.7;
        margin-bottom: 24px;
      }

      .info-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 16px;
        margin-bottom: 24px;

        .info-item {
          display: flex;
          align-items: center;
          gap: 12px;
          background: linear-gradient(135deg, #f8f9fa 0%, #fff 100%);
          padding: 14px;
          border-radius: 14px;
          border: 1px solid #eee;

          ion-icon {
            font-size: 28px;
            color: #1a5276;
          }

          .info-content {
            display: flex;
            flex-direction: column;

            .info-label {
              font-size: 11px;
              color: #95a5a6;
              text-transform: uppercase;
              letter-spacing: 0.5px;
            }

            .info-value {
              font-size: 14px;
              font-weight: 600;
              color: #2c3e50;

              &.price {
                color: #27ae60;
                font-size: 16px;
              }
            }
          }
        }
      }

      .atracciones-section {
        background: linear-gradient(135deg, #1a5276 0%, #2980b9 100%);
        padding: 20px;
        border-radius: 16px;
        margin-bottom: 24px;

        h3 {
          color: #fff;
          font-size: 16px;
          margin: 0 0 12px 0;
          display: flex;
          align-items: center;
          gap: 8px;

          ion-icon {
            color: #f39c12;
          }
        }

        p {
          color: rgba(255, 255, 255, 0.9);
          font-size: 14px;
          line-height: 1.6;
          margin: 0;
        }
      }

      .action-buttons {
        display: flex;
        flex-direction: column;
        gap: 12px;

        ion-button {
          --border-radius: 12px;
          height: 50px;
          font-weight: 600;
        }

        .tg-btn-primary {
          --background: linear-gradient(135deg, #f39c12 0%, #e67e22 100%);
          --color: #fff;
        }
      }
    }
  `],
  standalone: true,
  imports: [
    CommonModule,
    IonHeader,
    IonToolbar,
    IonTitle,
    IonContent,
    IonButton,
    IonIcon,
    IonButtons,
    IonChip,
    IonLabel
  ],
})
export class DestinoDetailModal implements OnInit {
  @Input() destino!: Destino;
  
  private modalController = inject(ModalController);
  private favoritosService = inject(FavoritosService);
  private toastController = inject(ToastController);

  isFavorite = false;

  constructor() {
    addIcons({
      closeOutline,
      heartOutline,
      heart,
      shareOutline,
      locationOutline,
      navigateOutline,
      airplaneOutline,
      calendarOutline,
      walletOutline,
      sunnyOutline,
      languageOutline,
      cashOutline,
      starOutline,
      mapOutline
    });
  }

  async ngOnInit() {
    this.isFavorite = await this.favoritosService.isFavorito(this.destino.nombre, 'invitado');
  }

  dismiss() {
    this.modalController.dismiss();
  }

  async toggleFavorite() {
    if (this.isFavorite) {
      const favId = await this.favoritosService.getFavoritoId(this.destino.nombre, 'invitado');
      if (favId) {
        await this.favoritosService.deleteFavorito(favId);
        this.isFavorite = false;
        this.showToast('Eliminado de favoritos');
      }
    } else {
      await this.favoritosService.addFavorito({
        destino: this.destino.nombre,
        usuario: 'invitado'
      });
      this.isFavorite = true;
      this.showToast('Agregado a favoritos');
    }
  }

  share() {
    if (navigator.share) {
      navigator.share({
        title: `TravelGo - ${this.destino.nombre}`,
        text: `Descubre ${this.destino.nombre}, ${this.destino.pais}. ${this.destino.descripcion}`,
        url: window.location.href
      });
    } else {
      this.showToast('Compartir no disponible en este dispositivo');
    }
  }

  reservar() {
    this.showToast('Redirigiendo a reservas...');
    this.dismiss();
  }

  verPaquetes() {
    this.dismiss();
  }

  async showToast(message: string) {
    const toast = await this.toastController.create({
      message,
      duration: 2000,
      position: 'bottom'
    });
    await toast.present();
  }
}
