import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import {
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonCardSubtitle,
  IonCardContent,
  IonButton,
  IonIcon,
  IonChip,
  IonLabel,
  IonGrid,
  IonRow,
  IonCol,
  IonImg,
  IonText,
  IonBadge,
  IonSkeletonText
} from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import {
  airplaneOutline,
  compassOutline,
  briefcaseOutline,
  locationOutline,
  starOutline,
  star,
  arrowForwardOutline,
  sparklesOutline
} from 'ionicons/icons';
import { DestinosService } from '../../services/destinos.service';
import { PaquetesService } from '../../services/paquetes.service';
import { Destino, Paquete } from '../../models/models';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-home',
  template: `
    <ion-header class="tg-header">
      <ion-toolbar>
        <ion-title>
          <div class="header-content">
            <ion-icon name="airplane-outline"></ion-icon>
            <span>TravelGo</span>
          </div>
        </ion-title>
      </ion-toolbar>
    </ion-header>

    <ion-content [fullscreen]="true">
      <!-- Hero Section -->
      <div class="hero-section">
        <div class="hero-overlay"></div>
        <div class="hero-content">
          <h1>Descubre el Mundo</h1>
          <p>Tu próxima aventura te espera</p>
          <ion-button class="tg-btn-secondary" (click)="goToDestinos()">
            Explorar Destinos
            <ion-icon name="arrow-forward-outline" slot="end"></ion-icon>
          </ion-button>
        </div>
      </div>

      <!-- Destinos Destacados -->
      <div class="tg-section tg-fade-in">
        <h2 class="tg-section-title">
          <ion-icon name="compass-outline"></ion-icon>
          Destinos Destacados
        </h2>
        
        <div class="horizontal-scroll">
          @for (destino of destinos$ | async; track destino.id) {
            <ion-card class="destination-card tg-card" (click)="openDestinoDetail(destino)">
              <div class="card-image-container">
                <img [src]="destino.imagen" [alt]="destino.nombre" 
                     onerror="this.src='https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=800'"/>
                <div class="card-overlay">
                  <ion-chip class="location-chip">
                    <ion-icon name="location-outline"></ion-icon>
                    <ion-label>{{ destino.pais }}</ion-label>
                  </ion-chip>
                </div>
              </div>
              <ion-card-header>
                <ion-card-title>{{ destino.nombre }}</ion-card-title>
                <ion-card-subtitle>{{ destino.descripcion }}</ion-card-subtitle>
              </ion-card-header>
            </ion-card>
          } @empty {
            <div class="skeleton-container">
              @for (i of [1,2,3]; track i) {
                <ion-card class="destination-card">
                  <ion-skeleton-text [animated]="true" style="height: 150px;"></ion-skeleton-text>
                  <ion-card-header>
                    <ion-skeleton-text [animated]="true" style="width: 60%;"></ion-skeleton-text>
                    <ion-skeleton-text [animated]="true" style="width: 80%;"></ion-skeleton-text>
                  </ion-card-header>
                </ion-card>
              }
            </div>
          }
        </div>
      </div>

      <!-- Paquetes Populares -->
      <div class="tg-section tg-fade-in">
        <h2 class="tg-section-title">
          <ion-icon name="briefcase-outline"></ion-icon>
          Paquetes Populares
        </h2>
        
        @for (paquete of paquetes$ | async; track paquete.id) {
          <ion-card class="package-card tg-card" (click)="openPaqueteDetail(paquete)">
            <ion-grid>
              <ion-row>
                <ion-col size="4">
                  <img [src]="paquete.imagen" [alt]="paquete.nombre" class="package-image"
                       onerror="this.src='https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=800'"/>
                </ion-col>
                <ion-col size="8">
                  <div class="package-info">
                    <h3>{{ paquete.nombre }}</h3>
                    <p>{{ paquete.descripcion }}</p>
                    <div class="price-container">
                      <span class="tg-price-badge">\${{ paquete.precio }} USD</span>
                    </div>
                  </div>
                </ion-col>
              </ion-row>
            </ion-grid>
          </ion-card>
        } @empty {
          @for (i of [1,2]; track i) {
            <ion-card class="package-card">
              <ion-grid>
                <ion-row>
                  <ion-col size="4">
                    <ion-skeleton-text [animated]="true" style="height: 100px; border-radius: 12px;"></ion-skeleton-text>
                  </ion-col>
                  <ion-col size="8">
                    <ion-skeleton-text [animated]="true" style="width: 70%; margin-bottom: 8px;"></ion-skeleton-text>
                    <ion-skeleton-text [animated]="true" style="width: 100%;"></ion-skeleton-text>
                    <ion-skeleton-text [animated]="true" style="width: 40%; margin-top: 12px;"></ion-skeleton-text>
                  </ion-col>
                </ion-row>
              </ion-grid>
            </ion-card>
          }
        }
      </div>

      <!-- CTA Section -->
      <div class="cta-section">
        <ion-icon name="sparkles-outline"></ion-icon>
        <h3>¿Listo para viajar?</h3>
        <p>Contáctanos y planificamos tu viaje ideal</p>
        <ion-button class="tg-btn-outline" (click)="goToContacto()">
          Contáctanos
        </ion-button>
      </div>
    </ion-content>
  `,
  styles: [`
    .header-content {
      display: flex;
      align-items: center;
      gap: 8px;
      
      ion-icon {
        font-size: 24px;
      }
    }

    .hero-section {
      position: relative;
      height: 280px;
      background: linear-gradient(135deg, rgba(26, 82, 118, 0.9) 0%, rgba(41, 128, 185, 0.8) 100%), url('https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=1200') center/cover no-repeat;
      background-color: #1a5276;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .hero-overlay {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: linear-gradient(135deg, rgba(26, 82, 118, 0.9) 0%, rgba(41, 128, 185, 0.7) 100%);
    }

    .hero-content {
      position: relative;
      z-index: 1;
      text-align: center;
      color: white;
      padding: 20px;

      h1 {
        font-size: 32px;
        font-weight: 700;
        margin-bottom: 8px;
        text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
      }

      p {
        font-size: 16px;
        margin-bottom: 20px;
        opacity: 0.9;
      }
    }

    .horizontal-scroll {
      display: flex;
      overflow-x: auto;
      gap: 16px;
      padding: 8px 0 16px;
      scroll-snap-type: x mandatory;
      -webkit-overflow-scrolling: touch;

      &::-webkit-scrollbar {
        display: none;
      }
    }

    .destination-card {
      flex: 0 0 260px;
      scroll-snap-align: start;
      margin: 0;

      .card-image-container {
        position: relative;
        height: 160px;
        overflow: hidden;

        img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }

        .card-overlay {
          position: absolute;
          top: 12px;
          left: 12px;
        }

        .location-chip {
          --background: rgba(255, 255, 255, 0.95);
          --color: #1a5276;
          font-size: 12px;
          height: 28px;
        }
      }

      ion-card-title {
        font-size: 18px;
        font-weight: 600;
        color: #2c3e50;
      }

      ion-card-subtitle {
        font-size: 13px;
        color: #7f8c8d;
        margin-top: 4px;
      }
    }

    .skeleton-container {
      display: flex;
      gap: 16px;
    }

    .package-card {
      margin: 0 0 16px;
      
      ion-grid {
        padding: 12px;
      }

      .package-image {
        width: 100%;
        height: 100px;
        object-fit: cover;
        border-radius: 12px;
      }

      .package-info {
        padding-left: 8px;

        h3 {
          font-size: 16px;
          font-weight: 600;
          color: #2c3e50;
          margin: 0 0 6px;
        }

        p {
          font-size: 13px;
          color: #7f8c8d;
          margin: 0 0 12px;
        }
      }

      .price-container {
        display: flex;
        justify-content: flex-start;
      }
    }

    .cta-section {
      background: linear-gradient(135deg, #f39c12 0%, #e74c3c 100%);
      margin: 20px;
      padding: 40px 24px;
      border-radius: 20px;
      text-align: center;
      color: white;

      ion-icon {
        font-size: 48px;
        margin-bottom: 16px;
      }

      h3 {
        font-size: 22px;
        font-weight: 700;
        margin-bottom: 8px;
      }

      p {
        font-size: 14px;
        opacity: 0.9;
        margin-bottom: 20px;
      }

      .tg-btn-outline {
        --border-color: white;
        --color: white;
      }
    }
  `],
  standalone: true,
  imports: [
    CommonModule,
    IonHeader,
    IonToolbar,
    IonTitle,
    IonContent,
    IonCard,
    IonCardHeader,
    IonCardTitle,
    IonCardSubtitle,
    IonCardContent,
    IonButton,
    IonIcon,
    IonChip,
    IonLabel,
    IonGrid,
    IonRow,
    IonCol,
    IonImg,
    IonText,
    IonBadge,
    IonSkeletonText
  ],
})
export class HomePage implements OnInit {
  private destinosService = inject(DestinosService);
  private paquetesService = inject(PaquetesService);
  private router = inject(Router);

  destinos$!: Observable<Destino[]>;
  paquetes$!: Observable<Paquete[]>;

  constructor() {
    addIcons({
      airplaneOutline,
      compassOutline,
      briefcaseOutline,
      locationOutline,
      starOutline,
      star,
      arrowForwardOutline,
      sparklesOutline
    });
  }

  ngOnInit() {
    this.destinos$ = this.destinosService.getDestinos();
    this.paquetes$ = this.paquetesService.getPaquetes();
  }

  goToDestinos() {
    this.router.navigate(['/tabs/destinos']);
  }

  goToContacto() {
    this.router.navigate(['/tabs/contacto']);
  }

  openDestinoDetail(destino: Destino) {
    // Navegar a destinos con detalle
    this.router.navigate(['/tabs/destinos'], { state: { destino } });
  }

  openPaqueteDetail(paquete: Paquete) {
    // Navegar a paquetes con detalle
    this.router.navigate(['/tabs/paquetes'], { state: { paquete } });
  }
}
