import { Routes } from '@angular/router';
import { TabsPage } from './tabs.page';

export const routes: Routes = [
  {
    path: 'tabs',
    component: TabsPage,
    children: [
      {
        path: 'home',
        loadComponent: () => import('../pages/home/home.page').then((m) => m.HomePage),
      },
      {
        path: 'destinos',
        loadComponent: () => import('../pages/destinos/destinos.page').then((m) => m.DestinosPage),
      },
      {
        path: 'paquetes',
        loadComponent: () => import('../pages/paquetes/paquetes.page').then((m) => m.PaquetesPage),
      },
      {
        path: 'favoritos',
        loadComponent: () => import('../pages/favoritos/favoritos.page').then((m) => m.FavoritosPage),
      },
      {
        path: 'contacto',
        loadComponent: () => import('../pages/contacto/contacto.page').then((m) => m.ContactoPage),
      },
      {
        path: '',
        redirectTo: '/tabs/home',
        pathMatch: 'full',
      },
    ],
  },
  {
    path: '',
    redirectTo: '/tabs/home',
    pathMatch: 'full',
  },
];
