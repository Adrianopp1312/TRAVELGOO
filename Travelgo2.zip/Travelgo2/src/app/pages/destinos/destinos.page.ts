import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonCardSubtitle,
  IonCardContent,
  IonButton,
  IonIcon,
  IonChip,
  IonLabel,
  IonGrid,
  IonRow,
  IonCol,
  IonFab,
  IonFabButton,
  IonModal,
  IonButtons,
  IonSearchbar,
  IonSkeletonText,
  IonRefresher,
  IonRefresherContent,
  ModalController,
  ToastController
} from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import {
  locationOutline,
  heartOutline,
  heart,
  closeOutline,
  shareOutline,
  navigateOutline,
  searchOutline,
  refreshOutline
} from 'ionicons/icons';
import { DestinosService } from '../../services/destinos.service';
import { FavoritosService } from '../../services/favoritos.service';
import { Destino } from '../../models/models';
import { Observable, BehaviorSubject, combineLatest, map } from 'rxjs';
import { DestinoDetailModal } from '../../modals/destino-detail.modal';

@Component({
  selector: 'app-destinos',
  template: `
    <ion-header class="tg-header">
      <ion-toolbar>
        <ion-title>
          <ion-icon name="location-outline"></ion-icon>
          Destinos
        </ion-title>
      </ion-toolbar>
      <ion-toolbar>
        <ion-searchbar 
          placeholder="Buscar destinos..."
          [debounce]="300"
          (ionInput)="onSearch($event)"
          class="tg-searchbar">
        </ion-searchbar>
      </ion-toolbar>
    </ion-header>

    <ion-content [fullscreen]="true">
      <ion-refresher slot="fixed" (ionRefresh)="doRefresh($event)">
        <ion-refresher-content pullingIcon="refresh-outline" refreshingSpinner="circles">
        </ion-refresher-content>
      </ion-refresher>

      <div class="destinos-container tg-fade-in">
        <div class="destinos-header">
          <h2>Explora el Mundo</h2>
          <p>Descubre destinos increíbles para tu próximo viaje</p>
        </div>

        <ion-grid>
          <ion-row>
            @for (destino of filteredDestinos$ | async; track destino.id) {
              <ion-col size="12" sizeMd="6" sizeLg="4">
                <ion-card class="destino-card tg-card" (click)="openDetail(destino)">
                  <div class="card-image-wrapper">
                    <img [src]="destino.imagen" [alt]="destino.nombre"
                         onerror="this.src='https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=800'"/>
                    <div class="image-overlay">
                      <ion-button 
                        fill="clear" 
                        class="favorite-btn"
                        (click)="toggleFavorite($event, destino)">
                        <ion-icon [name]="isFavorite(destino.nombre) ? 'heart' : 'heart-outline'" 
                                  [class.is-favorite]="isFavorite(destino.nombre)">
                        </ion-icon>
                      </ion-button>
                    </div>
                    <ion-chip class="country-chip">
                      <ion-icon name="navigate-outline"></ion-icon>
                      <ion-label>{{ destino.pais }}</ion-label>
                    </ion-chip>
                  </div>
                  <ion-card-header>
                    <ion-card-title>{{ destino.nombre }}</ion-card-title>
                    <ion-card-subtitle>
                      <ion-icon name="location-outline"></ion-icon>
                      {{ destino.descripcion }}
                    </ion-card-subtitle>
                  </ion-card-header>
                  <ion-card-content>
                    <ion-button expand="block" class="tg-btn-primary" size="small">
                      Ver Detalles
                    </ion-button>
                  </ion-card-content>
                </ion-card>
              </ion-col>
            } @empty {
              @if (isLoading) {
                @for (i of [1,2,3,4]; track i) {
                  <ion-col size="12" sizeMd="6">
                    <ion-card class="destino-card">
                      <ion-skeleton-text [animated]="true" style="height: 180px;"></ion-skeleton-text>
                      <ion-card-header>
                        <ion-skeleton-text [animated]="true" style="width: 60%;"></ion-skeleton-text>
                        <ion-skeleton-text [animated]="true" style="width: 80%;"></ion-skeleton-text>
                      </ion-card-header>
                      <ion-card-content>
                        <ion-skeleton-text [animated]="true" style="height: 36px;"></ion-skeleton-text>
                      </ion-card-content>
                    </ion-card>
                  </ion-col>
                }
              } @else {
                <ion-col size="12">
                  <div class="tg-empty-state">
                    <ion-icon name="search-outline"></ion-icon>
                    <h3>No se encontraron destinos</h3>
                    <p>Intenta con otra búsqueda</p>
                  </div>
                </ion-col>
              }
            }
          </ion-row>
        </ion-grid>
      </div>
    </ion-content>
  `,
  styles: [`
    ion-toolbar ion-title {
      display: flex;
      align-items: center;
      gap: 8px;
      
      ion-icon {
        font-size: 22px;
      }
    }

    .tg-searchbar {
      --background: #f8f9fa;
      --border-radius: 12px;
      --box-shadow: none;
      padding: 0 12px 12px;
    }

    .destinos-container {
      padding: 20px 12px;
    }

    .destinos-header {
      text-align: center;
      margin-bottom: 24px;

      h2 {
        font-size: 26px;
        font-weight: 700;
        color: #2c3e50;
        margin-bottom: 8px;
      }

      p {
        font-size: 14px;
        color: #7f8c8d;
      }
    }

    .destino-card {
      margin-bottom: 16px;
      overflow: hidden;

      .card-image-wrapper {
        position: relative;
        height: 180px;
        overflow: hidden;

        img {
          width: 100%;
          height: 100%;
          object-fit: cover;
          transition: transform 0.3s ease;
        }

        .image-overlay {
          position: absolute;
          top: 0;
          right: 0;
          padding: 8px;
        }

        .favorite-btn {
          --padding-start: 8px;
          --padding-end: 8px;
          
          ion-icon {
            font-size: 28px;
            color: white;
            filter: drop-shadow(0 2px 4px rgba(0,0,0,0.3));
            transition: all 0.3s ease;

            &.is-favorite {
              color: #e74c3c;
              transform: scale(1.1);
            }
          }
        }

        .country-chip {
          position: absolute;
          bottom: 12px;
          left: 12px;
          --background: rgba(255, 255, 255, 0.95);
          --color: #1a5276;
          font-weight: 500;
          font-size: 12px;
        }
      }

      &:active .card-image-wrapper img {
        transform: scale(1.05);
      }

      ion-card-title {
        font-size: 20px;
        font-weight: 600;
        color: #2c3e50;
      }

      ion-card-subtitle {
        display: flex;
        align-items: center;
        gap: 4px;
        font-size: 13px;
        color: #7f8c8d;
        margin-top: 6px;
      }

      ion-card-content {
        padding-top: 12px;
      }
    }
  `],
  standalone: true,
  imports: [
    CommonModule,
    IonHeader,
    IonToolbar,
    IonTitle,
    IonContent,
    IonCard,
    IonCardHeader,
    IonCardTitle,
    IonCardSubtitle,
    IonCardContent,
    IonButton,
    IonIcon,
    IonChip,
    IonLabel,
    IonGrid,
    IonRow,
    IonCol,
    IonFab,
    IonFabButton,
    IonModal,
    IonButtons,
    IonSearchbar,
    IonSkeletonText,
    IonRefresher,
    IonRefresherContent
  ],
})
export class DestinosPage implements OnInit {
  private destinosService = inject(DestinosService);
  private favoritosService = inject(FavoritosService);
  private modalController = inject(ModalController);
  private toastController = inject(ToastController);

  destinos$!: Observable<Destino[]>;
  filteredDestinos$!: Observable<Destino[]>;
  private searchTerm$ = new BehaviorSubject<string>('');
  
  favoritos: Set<string> = new Set();
  isLoading = true;

  constructor() {
    addIcons({
      locationOutline,
      heartOutline,
      heart,
      closeOutline,
      shareOutline,
      navigateOutline,
      searchOutline,
      refreshOutline
    });
  }

  ngOnInit() {
    this.loadDestinos();
    this.loadFavoritos();
  }

  loadDestinos() {
    this.destinos$ = this.destinosService.getDestinos();
    
    this.filteredDestinos$ = combineLatest([
      this.destinos$,
      this.searchTerm$
    ]).pipe(
      map(([destinos, term]) => {
        this.isLoading = false;
        if (!term.trim()) return destinos;
        const lowerTerm = term.toLowerCase();
        return destinos.filter(d => 
          d.nombre.toLowerCase().includes(lowerTerm) ||
          d.pais.toLowerCase().includes(lowerTerm) ||
          d.descripcion.toLowerCase().includes(lowerTerm)
        );
      })
    );
  }

  loadFavoritos() {
    this.favoritosService.getFavoritos().subscribe(favs => {
      this.favoritos = new Set(favs.map(f => f.destino));
    });
  }

  onSearch(event: any) {
    const term = event.target.value || '';
    this.searchTerm$.next(term);
  }

  isFavorite(destinoNombre: string): boolean {
    return this.favoritos.has(destinoNombre);
  }

  async toggleFavorite(event: Event, destino: Destino) {
    event.stopPropagation();
    
    if (this.isFavorite(destino.nombre)) {
      // Remover de favoritos
      const favId = await this.favoritosService.getFavoritoId(destino.nombre, 'invitado');
      if (favId) {
        await this.favoritosService.deleteFavorito(favId);
        this.favoritos.delete(destino.nombre);
        this.showToast('Eliminado de favoritos', 'heart-outline');
      }
    } else {
      // Agregar a favoritos
      await this.favoritosService.addFavorito({
        destino: destino.nombre,
        usuario: 'invitado'
      });
      this.favoritos.add(destino.nombre);
      this.showToast('Agregado a favoritos', 'heart');
    }
  }

  async openDetail(destino: Destino) {
    const modal = await this.modalController.create({
      component: DestinoDetailModal,
      componentProps: { destino }
    });
    await modal.present();
  }

  async doRefresh(event: any) {
    this.loadDestinos();
    this.loadFavoritos();
    setTimeout(() => {
      event.target.complete();
    }, 1000);
  }

  async showToast(message: string, icon: string) {
    const toast = await this.toastController.create({
      message,
      duration: 2000,
      position: 'bottom',
      icon,
      cssClass: 'tg-toast'
    });
    await toast.present();
  }
}
