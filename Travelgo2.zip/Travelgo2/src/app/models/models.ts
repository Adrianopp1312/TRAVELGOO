// Modelo para Destinos
export interface Destino {
  id?: string;
  nombre: string;
  descripcion: string;
  pais: string;
  imagen: string;
  continente?: string;
  idioma?: string;
  moneda?: string;
  clima?: string;
  mejorEpoca?: string;
  atracciones?: string;
  precio?: string;
}

// Modelo para Paquetes
export interface Paquete {
  id?: string;
  nombre: string;
  descripcion: string;
  precio: string;
  imagen: string;
  duracion?: string;
  incluye?: string;
  destinos?: string;
  salida?: string;
  calificacion?: number;
  tipo?: string;
}

// Modelo para Favoritos
export interface Favorito {
  id?: string;
  destino: string;
  usuario: string;
}

// Modelo para Mensajes
export interface Mensaje {
  id?: string;
  nombre: string;
  correo: string;
  mensaje: string;
  fecha?: Date;
}
