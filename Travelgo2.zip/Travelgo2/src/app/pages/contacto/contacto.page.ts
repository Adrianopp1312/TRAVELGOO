import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonCardContent,
  IonButton,
  IonIcon,
  IonInput,
  IonTextarea,
  IonItem,
  IonLabel,
  IonList,
  IonNote,
  LoadingController,
  ToastController,
  AlertController
} from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import {
  chatbubblesOutline,
  personOutline,
  mailOutline,
  sendOutline,
  callOutline,
  locationOutline,
  timeOutline,
  logoWhatsapp,
  logoInstagram,
  logoFacebook,
  checkmarkCircle
} from 'ionicons/icons';
import { MensajesService } from '../../services/mensajes.service';
import { Mensaje } from '../../models/models';

@Component({
  selector: 'app-contacto',
  template: `
    <ion-header class="tg-header">
      <ion-toolbar>
        <ion-title>
          <ion-icon name="chatbubbles-outline"></ion-icon>
          Contacto
        </ion-title>
      </ion-toolbar>
    </ion-header>

    <ion-content [fullscreen]="true">
      <div class="contacto-container tg-fade-in">
        <!-- Header -->
        <div class="contacto-header">
          <div class="icon-container">
            <ion-icon name="chatbubbles-outline"></ion-icon>
          </div>
          <h1>¿Tienes preguntas?</h1>
          <p>Estamos aquí para ayudarte a planificar tu viaje perfecto</p>
        </div>

        <!-- Formulario de contacto -->
        <ion-card class="contact-form-card tg-card">
          <ion-card-header>
            <ion-card-title>Envíanos un mensaje</ion-card-title>
          </ion-card-header>
          <ion-card-content>
            <form (ngSubmit)="enviarMensaje()">
              <div class="form-group">
                <ion-item class="input-item" lines="none">
                  <ion-icon name="person-outline" slot="start"></ion-icon>
                  <ion-input 
                    type="text" 
                    placeholder="Tu nombre completo"
                    [(ngModel)]="mensaje.nombre"
                    name="nombre"
                    required>
                  </ion-input>
                </ion-item>
              </div>

              <div class="form-group">
                <ion-item class="input-item" lines="none">
                  <ion-icon name="mail-outline" slot="start"></ion-icon>
                  <ion-input 
                    type="email" 
                    placeholder="tu@correo.com"
                    [(ngModel)]="mensaje.correo"
                    name="correo"
                    required>
                  </ion-input>
                </ion-item>
              </div>

              <div class="form-group">
                <ion-item class="textarea-item" lines="none">
                  <ion-textarea 
                    placeholder="Escribe tu mensaje aquí..."
                    [(ngModel)]="mensaje.mensaje"
                    name="mensaje"
                    [rows]="5"
                    required>
                  </ion-textarea>
                </ion-item>
              </div>

              <ion-button 
                expand="block" 
                class="tg-btn-primary submit-btn"
                type="submit"
                [disabled]="!isFormValid()">
                <ion-icon name="send-outline" slot="start"></ion-icon>
                Enviar Mensaje
              </ion-button>
            </form>
          </ion-card-content>
        </ion-card>

        <!-- Información de contacto -->
        <div class="contact-info">
          <h3>Otras formas de contactarnos</h3>
          
          <ion-list lines="none" class="contact-list">
            <ion-item class="contact-item" (click)="openPhone()">
              <div class="contact-icon phone" slot="start">
                <ion-icon name="call-outline"></ion-icon>
              </div>
              <ion-label>
                <h2>Teléfono</h2>
                <p>+52 443 123 4567</p>
              </ion-label>
            </ion-item>

            <ion-item class="contact-item" (click)="openWhatsApp()">
              <div class="contact-icon whatsapp" slot="start">
                <ion-icon name="logo-whatsapp"></ion-icon>
              </div>
              <ion-label>
                <h2>WhatsApp</h2>
                <p>+52 443 123 4567</p>
              </ion-label>
            </ion-item>

            <ion-item class="contact-item" (click)="openEmail()">
              <div class="contact-icon email" slot="start">
                <ion-icon name="mail-outline"></ion-icon>
              </div>
              <ion-label>
                <h2>Email</h2>
                <p>info&#64;travelgo.com</p>
              </ion-label>
            </ion-item>

            <ion-item class="contact-item">
              <div class="contact-icon location" slot="start">
                <ion-icon name="location-outline"></ion-icon>
              </div>
              <ion-label>
                <h2>Ubicación</h2>
                <p>Morelia, Michoacán, México</p>
              </ion-label>
            </ion-item>

            <ion-item class="contact-item">
              <div class="contact-icon time" slot="start">
                <ion-icon name="time-outline"></ion-icon>
              </div>
              <ion-label>
                <h2>Horario</h2>
                <p>Lun - Vie: 9:00 AM - 6:00 PM</p>
              </ion-label>
            </ion-item>
          </ion-list>
        </div>

        <!-- Redes sociales -->
        <div class="social-section">
          <h3>Síguenos en redes</h3>
          <div class="social-icons">
            <ion-button fill="clear" class="social-btn facebook">
              <ion-icon name="logo-facebook"></ion-icon>
            </ion-button>
            <ion-button fill="clear" class="social-btn instagram">
              <ion-icon name="logo-instagram"></ion-icon>
            </ion-button>
            <ion-button fill="clear" class="social-btn whatsapp">
              <ion-icon name="logo-whatsapp"></ion-icon>
            </ion-button>
          </div>
        </div>
      </div>
    </ion-content>
  `,
  styles: [`
    ion-toolbar ion-title {
      display: flex;
      align-items: center;
      gap: 8px;
      
      ion-icon {
        font-size: 22px;
      }
    }

    .contacto-container {
      padding: 20px 16px;
    }

    .contacto-header {
      text-align: center;
      margin-bottom: 32px;

      .icon-container {
        width: 90px;
        height: 90px;
        background: linear-gradient(135deg, #1a5276 0%, #2980b9 100%);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 20px;
        box-shadow: 0 10px 30px rgba(26, 82, 118, 0.3);

        ion-icon {
          font-size: 45px;
          color: white;
        }
      }

      h1 {
        font-size: 26px;
        font-weight: 700;
        color: #2c3e50;
        margin-bottom: 8px;
      }

      p {
        font-size: 14px;
        color: #7f8c8d;
        max-width: 280px;
        margin: 0 auto;
      }
    }

    .contact-form-card {
      margin-bottom: 32px;

      ion-card-title {
        font-size: 18px;
        font-weight: 600;
        color: #2c3e50;
      }

      .form-group {
        margin-bottom: 16px;
      }

      .input-item, .textarea-item {
        --background: #f8f9fa;
        --border-radius: 12px;
        --padding-start: 16px;
        --min-height: 52px;

        ion-icon {
          color: #7f8c8d;
          font-size: 20px;
          margin-right: 12px;
        }

        ion-input, ion-textarea {
          --placeholder-color: #95a5a6;
          font-size: 15px;
        }
      }

      .textarea-item {
        --padding-top: 12px;
        --padding-bottom: 12px;
      }

      .submit-btn {
        margin-top: 8px;
      }
    }

    .contact-info {
      margin-bottom: 32px;

      h3 {
        font-size: 18px;
        font-weight: 600;
        color: #2c3e50;
        margin-bottom: 16px;
        text-align: center;
      }

      .contact-list {
        background: transparent;

        .contact-item {
          --background: white;
          --padding-start: 16px;
          --padding-end: 16px;
          --padding-top: 14px;
          --padding-bottom: 14px;
          margin-bottom: 12px;
          border-radius: 14px;
          box-shadow: 0 3px 12px rgba(0, 0, 0, 0.06);
          cursor: pointer;

          .contact-icon {
            width: 48px;
            height: 48px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 16px;

            ion-icon {
              font-size: 24px;
              color: white;
            }

            &.phone { background: linear-gradient(135deg, #3498db, #2980b9); }
            &.whatsapp { background: linear-gradient(135deg, #25d366, #128c7e); }
            &.email { background: linear-gradient(135deg, #e74c3c, #c0392b); }
            &.location { background: linear-gradient(135deg, #f39c12, #d68910); }
            &.time { background: linear-gradient(135deg, #9b59b6, #8e44ad); }
          }

          ion-label {
            h2 {
              font-size: 15px;
              font-weight: 600;
              color: #2c3e50;
              margin-bottom: 4px;
            }

            p {
              font-size: 13px;
              color: #7f8c8d;
            }
          }
        }
      }
    }

    .social-section {
      text-align: center;
      padding: 24px;
      background: linear-gradient(135deg, rgba(26, 82, 118, 0.05) 0%, rgba(41, 128, 185, 0.05) 100%);
      border-radius: 20px;

      h3 {
        font-size: 16px;
        font-weight: 600;
        color: #2c3e50;
        margin-bottom: 20px;
      }

      .social-icons {
        display: flex;
        justify-content: center;
        gap: 16px;

        .social-btn {
          width: 56px;
          height: 56px;
          --border-radius: 50%;

          ion-icon {
            font-size: 28px;
          }

          &.facebook {
            --background: #3b5998;
            ion-icon { color: #3b5998; }
          }

          &.instagram {
            ion-icon { color: #e4405f; }
          }

          &.whatsapp {
            ion-icon { color: #25d366; }
          }
        }
      }
    }
  `],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    IonHeader,
    IonToolbar,
    IonTitle,
    IonContent,
    IonCard,
    IonCardHeader,
    IonCardTitle,
    IonCardContent,
    IonButton,
    IonIcon,
    IonInput,
    IonTextarea,
    IonItem,
    IonLabel,
    IonList,
    IonNote
  ],
})
export class ContactoPage {
  private mensajesService = inject(MensajesService);
  private loadingController = inject(LoadingController);
  private toastController = inject(ToastController);
  private alertController = inject(AlertController);

  mensaje: Mensaje = {
    nombre: '',
    correo: '',
    mensaje: ''
  };

  constructor() {
    addIcons({
      chatbubblesOutline,
      personOutline,
      mailOutline,
      sendOutline,
      callOutline,
      locationOutline,
      timeOutline,
      logoWhatsapp,
      logoInstagram,
      logoFacebook,
      checkmarkCircle
    });
  }

  isFormValid(): boolean {
    return !!(this.mensaje.nombre && 
              this.mensaje.correo && 
              this.mensaje.mensaje &&
              this.isValidEmail(this.mensaje.correo));
  }

  isValidEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  async enviarMensaje() {
    if (!this.isFormValid()) {
      this.showToast('Por favor completa todos los campos correctamente', 'warning');
      return;
    }

    const loading = await this.loadingController.create({
      message: 'Enviando mensaje...',
      spinner: 'circles'
    });
    await loading.present();

    try {
      await this.mensajesService.sendMensaje(this.mensaje);
      await loading.dismiss();
      
      await this.showSuccessAlert();
      
      // Limpiar formulario
      this.mensaje = {
        nombre: '',
        correo: '',
        mensaje: ''
      };
    } catch (error) {
      await loading.dismiss();
      this.showToast('Error al enviar el mensaje. Intenta de nuevo.', 'danger');
    }
  }

  async showSuccessAlert() {
    const alert = await this.alertController.create({
      header: '¡Mensaje Enviado!',
      message: 'Gracias por contactarnos. Te responderemos a la brevedad.',
      buttons: ['Aceptar'],
      cssClass: 'success-alert'
    });
    await alert.present();
  }

  async showToast(message: string, color: string = 'primary') {
    const toast = await this.toastController.create({
      message,
      duration: 3000,
      position: 'bottom',
      color
    });
    await toast.present();
  }

  openPhone() {
    window.open('tel:+524431234567', '_system');
  }

  openWhatsApp() {
    window.open('https://wa.me/524431234567', '_blank');
  }

  openEmail() {
    window.open('mailto:info@travelgo.com', '_system');
  }
}
