import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonCardSubtitle,
  IonCardContent,
  IonButton,
  IonIcon,
  IonChip,
  IonLabel,
  IonGrid,
  IonRow,
  IonCol,
  IonSegment,
  IonSegmentButton,
  IonBadge,
  IonSkeletonText,
  IonRefresher,
  IonRefresherContent,
  ModalController,
  ToastController
} from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import {
  briefcaseOutline,
  pricetagOutline,
  timeOutline,
  peopleOutline,
  starOutline,
  star,
  checkmarkCircleOutline,
  informationCircleOutline,
  refreshOutline
} from 'ionicons/icons';
import { PaquetesService } from '../../services/paquetes.service';
import { Paquete } from '../../models/models';
import { Observable } from 'rxjs';
import { PaqueteDetailModal } from '../../modals/paquete-detail.modal';

@Component({
  selector: 'app-paquetes',
  template: `
    <ion-header class="tg-header">
      <ion-toolbar>
        <ion-title>
          <ion-icon name="briefcase-outline"></ion-icon>
          Paquetes de Viaje
        </ion-title>
      </ion-toolbar>
      <ion-toolbar>
        <ion-segment [(ngModel)]="selectedSegment" (ionChange)="segmentChanged($event)">
          <ion-segment-button value="todos">
            <ion-label>Todos</ion-label>
          </ion-segment-button>
          <ion-segment-button value="ofertas">
            <ion-label>Ofertas</ion-label>
          </ion-segment-button>
          <ion-segment-button value="premium">
            <ion-label>Premium</ion-label>
          </ion-segment-button>
        </ion-segment>
      </ion-toolbar>
    </ion-header>

    <ion-content [fullscreen]="true">
      <ion-refresher slot="fixed" (ionRefresh)="doRefresh($event)">
        <ion-refresher-content pullingIcon="refresh-outline" refreshingSpinner="circles">
        </ion-refresher-content>
      </ion-refresher>

      <div class="paquetes-container tg-fade-in">
        <div class="paquetes-header">
          <h2>Nuestros Paquetes</h2>
          <p>Experiencias completas para viajeros exigentes</p>
        </div>

        @for (paquete of paquetes$ | async; track paquete.id) {
          <ion-card class="paquete-card tg-card" (click)="openDetail(paquete)">
            <div class="card-layout">
              <div class="image-section">
                <img [src]="paquete.imagen" [alt]="paquete.nombre"
                     onerror="this.src='https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=800'"/>
                <ion-badge class="price-badge">
                  <ion-icon name="pricetag-outline"></ion-icon>
                  \${{ paquete.precio }} USD
                </ion-badge>
              </div>
              
              <div class="info-section">
                <ion-card-header>
                  <ion-card-title>{{ paquete.nombre }}</ion-card-title>
                  <ion-card-subtitle>
                    <ion-icon name="time-outline"></ion-icon>
                    {{ paquete.descripcion }}
                  </ion-card-subtitle>
                </ion-card-header>

                <ion-card-content>
                  <div class="features-row">
                    <ion-chip class="feature-chip">
                      <ion-icon name="checkmark-circle-outline"></ion-icon>
                      <ion-label>Todo incluido</ion-label>
                    </ion-chip>
                    <ion-chip class="feature-chip">
                      <ion-icon name="people-outline"></ion-icon>
                      <ion-label>2+ personas</ion-label>
                    </ion-chip>
                  </div>
                  
                  <div class="rating">
                    @for (i of [1,2,3,4,5]; track i) {
                      <ion-icon name="star" class="star-filled"></ion-icon>
                    }
                    <span>(4.8)</span>
                  </div>

                  <ion-button expand="block" class="tg-btn-primary" size="small">
                    Ver Detalles
                    <ion-icon name="information-circle-outline" slot="end"></ion-icon>
                  </ion-button>
                </ion-card-content>
              </div>
            </div>
          </ion-card>
        } @empty {
          @if (isLoading) {
            @for (i of [1,2,3]; track i) {
              <ion-card class="paquete-card">
                <ion-skeleton-text [animated]="true" style="height: 180px;"></ion-skeleton-text>
                <ion-card-header>
                  <ion-skeleton-text [animated]="true" style="width: 70%;"></ion-skeleton-text>
                  <ion-skeleton-text [animated]="true" style="width: 50%;"></ion-skeleton-text>
                </ion-card-header>
                <ion-card-content>
                  <ion-skeleton-text [animated]="true" style="height: 40px;"></ion-skeleton-text>
                </ion-card-content>
              </ion-card>
            }
          } @else {
            <div class="tg-empty-state">
              <ion-icon name="briefcase-outline"></ion-icon>
              <h3>No hay paquetes disponibles</h3>
              <p>Vuelve pronto para ver nuevas ofertas</p>
            </div>
          }
        }
      </div>
    </ion-content>
  `,
  styles: [`
    ion-toolbar ion-title {
      display: flex;
      align-items: center;
      gap: 8px;
      
      ion-icon {
        font-size: 22px;
      }
    }

    ion-segment {
      padding: 0 16px 12px;
      
      ion-segment-button {
        --indicator-color: #1a5276;
        --color-checked: #1a5276;
        font-weight: 500;
        text-transform: none;
      }
    }

    .paquetes-container {
      padding: 20px 16px;
    }

    .paquetes-header {
      text-align: center;
      margin-bottom: 24px;

      h2 {
        font-size: 26px;
        font-weight: 700;
        color: #2c3e50;
        margin-bottom: 8px;
      }

      p {
        font-size: 14px;
        color: #7f8c8d;
      }
    }

    .paquete-card {
      margin-bottom: 20px;
      overflow: hidden;

      .card-layout {
        display: flex;
        flex-direction: column;
      }

      .image-section {
        position: relative;
        height: 180px;

        img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }

        .price-badge {
          position: absolute;
          top: 12px;
          right: 12px;
          --background: linear-gradient(135deg, #f39c12 0%, #e74c3c 100%);
          --color: white;
          padding: 8px 14px;
          font-size: 14px;
          font-weight: 700;
          border-radius: 20px;
          display: flex;
          align-items: center;
          gap: 6px;

          ion-icon {
            font-size: 16px;
          }
        }
      }

      .info-section {
        ion-card-title {
          font-size: 20px;
          font-weight: 600;
          color: #2c3e50;
        }

        ion-card-subtitle {
          display: flex;
          align-items: center;
          gap: 6px;
          font-size: 14px;
          color: #7f8c8d;
          margin-top: 6px;
        }

        .features-row {
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
          margin-bottom: 12px;

          .feature-chip {
            --background: rgba(39, 174, 96, 0.1);
            --color: #27ae60;
            font-size: 12px;
            height: 30px;

            ion-icon {
              font-size: 16px;
            }
          }
        }

        .rating {
          display: flex;
          align-items: center;
          gap: 4px;
          margin-bottom: 16px;

          .star-filled {
            color: #f39c12;
            font-size: 18px;
          }

          span {
            font-size: 14px;
            color: #7f8c8d;
            margin-left: 8px;
          }
        }
      }
    }

    @media (min-width: 768px) {
      .paquete-card .card-layout {
        flex-direction: row;

        .image-section {
          width: 40%;
          height: auto;
          min-height: 220px;
        }

        .info-section {
          width: 60%;
        }
      }
    }
  `],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    IonHeader,
    IonToolbar,
    IonTitle,
    IonContent,
    IonCard,
    IonCardHeader,
    IonCardTitle,
    IonCardSubtitle,
    IonCardContent,
    IonButton,
    IonIcon,
    IonChip,
    IonLabel,
    IonGrid,
    IonRow,
    IonCol,
    IonSegment,
    IonSegmentButton,
    IonBadge,
    IonSkeletonText,
    IonRefresher,
    IonRefresherContent
  ],
})
export class PaquetesPage implements OnInit {
  private paquetesService = inject(PaquetesService);
  private modalController = inject(ModalController);
  private toastController = inject(ToastController);

  paquetes$!: Observable<Paquete[]>;
  selectedSegment = 'todos';
  isLoading = true;

  constructor() {
    addIcons({
      briefcaseOutline,
      pricetagOutline,
      timeOutline,
      peopleOutline,
      starOutline,
      star,
      checkmarkCircleOutline,
      informationCircleOutline,
      refreshOutline
    });
  }

  ngOnInit() {
    this.loadPaquetes();
  }

  loadPaquetes() {
    this.paquetes$ = this.paquetesService.getPaquetes();
    this.paquetes$.subscribe(() => {
      this.isLoading = false;
    });
  }

  segmentChanged(event: any) {
    this.selectedSegment = event.detail.value;
    // Aquí podrías filtrar por tipo de paquete
  }

  async openDetail(paquete: Paquete) {
    const modal = await this.modalController.create({
      component: PaqueteDetailModal,
      componentProps: { paquete }
    });
    await modal.present();
  }

  async doRefresh(event: any) {
    this.loadPaquetes();
    setTimeout(() => {
      event.target.complete();
    }, 1000);
  }
}
