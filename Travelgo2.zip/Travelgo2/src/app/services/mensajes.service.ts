import { Injectable, inject } from '@angular/core';
import { 
  Firestore, 
  collection, 
  collectionData, 
  addDoc,
  Timestamp
} from '@angular/fire/firestore';
import { Observable } from 'rxjs';
import { Mensaje } from '../models/models';

@Injectable({
  providedIn: 'root'
})
export class MensajesService {
  private firestore = inject(Firestore);
  private collectionName = 'mensajes';

  // Obtener todos los mensajes
  getMensajes(): Observable<Mensaje[]> {
    const mensajesRef = collection(this.firestore, this.collectionName);
    return collectionData(mensajesRef, { idField: 'id' }) as Observable<Mensaje[]>;
  }

  // Enviar un mensaje
  async sendMensaje(mensaje: Mensaje): Promise<void> {
    const mensajesRef = collection(this.firestore, this.collectionName);
    await addDoc(mensajesRef, {
      ...mensaje,
      fecha: Timestamp.now()
    });
  }
}
