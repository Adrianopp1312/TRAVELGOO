import { Injectable, inject } from '@angular/core';
import { 
  Firestore, 
  collection, 
  collectionData, 
  doc, 
  addDoc, 
  deleteDoc,
  query,
  where,
  getDocs
} from '@angular/fire/firestore';
import { Observable } from 'rxjs';
import { Favorito } from '../models/models';

@Injectable({
  providedIn: 'root'
})
export class FavoritosService {
  private firestore = inject(Firestore);
  private collectionName = 'favoritos';

  // Obtener todos los favoritos
  getFavoritos(): Observable<Favorito[]> {
    const favoritosRef = collection(this.firestore, this.collectionName);
    return collectionData(favoritosRef, { idField: 'id' }) as Observable<Favorito[]>;
  }

  // Obtener favoritos por usuario
  getFavoritosByUsuario(usuario: string): Observable<Favorito[]> {
    const favoritosRef = collection(this.firestore, this.collectionName);
    const q = query(favoritosRef, where('usuario', '==', usuario));
    return collectionData(q, { idField: 'id' }) as Observable<Favorito[]>;
  }

  // Agregar a favoritos
  async addFavorito(favorito: Favorito): Promise<void> {
    const favoritosRef = collection(this.firestore, this.collectionName);
    await addDoc(favoritosRef, favorito);
  }

  // Eliminar de favoritos
  async deleteFavorito(id: string): Promise<void> {
    const favoritoRef = doc(this.firestore, this.collectionName, id);
    await deleteDoc(favoritoRef);
  }

  // Verificar si un destino está en favoritos
  async isFavorito(destino: string, usuario: string): Promise<boolean> {
    const favoritosRef = collection(this.firestore, this.collectionName);
    const q = query(
      favoritosRef, 
      where('destino', '==', destino),
      where('usuario', '==', usuario)
    );
    const snapshot = await getDocs(q);
    return !snapshot.empty;
  }

  // Obtener ID del favorito
  async getFavoritoId(destino: string, usuario: string): Promise<string | null> {
    const favoritosRef = collection(this.firestore, this.collectionName);
    const q = query(
      favoritosRef, 
      where('destino', '==', destino),
      where('usuario', '==', usuario)
    );
    const snapshot = await getDocs(q);
    if (!snapshot.empty) {
      return snapshot.docs[0].id;
    }
    return null;
  }
}
