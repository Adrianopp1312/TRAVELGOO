import { Component, Input, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonButton,
  IonIcon,
  IonButtons,
  IonChip,
  IonLabel,
  IonBadge,
  ModalController,
  ToastController
} from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import {
  closeOutline,
  airplaneOutline,
  calendarOutline,
  checkmarkCircleOutline,
  starOutline,
  star,
  locationOutline,
  timeOutline,
  walletOutline,
  peopleOutline,
  bedOutline,
  restaurantOutline,
  busOutline,
  cameraOutline,
  shieldCheckmarkOutline
} from 'ionicons/icons';
import { Paquete } from '../models/models';

@Component({
  selector: 'app-paquete-detail-modal',
  template: `
    <ion-header>
      <ion-toolbar>
        <ion-title>{{ paquete.nombre }}</ion-title>
        <ion-buttons slot="end">
          <ion-button (click)="dismiss()">
            <ion-icon name="close-outline"></ion-icon>
          </ion-button>
        </ion-buttons>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding">
      <div class="modal-content tg-slide-up">
        <!-- Imagen principal -->
        <div class="image-container">
          <img [src]="paquete.imagen" [alt]="paquete.nombre"
               onerror="this.src='https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=800'"/>
          <div class="price-badge">
            <span class="price">\${{ paquete.precio }}</span>
            <span class="currency">USD</span>
          </div>
          <div class="type-badge" *ngIf="paquete.tipo">
            {{ paquete.tipo }}
          </div>
        </div>

        <!-- Info básica -->
        <div class="paquete-info">
          <div class="paquete-header">
            <h1>{{ paquete.nombre }}</h1>
            <div class="rating" *ngIf="paquete.calificacion">
              <ion-icon *ngFor="let s of getStars(paquete.calificacion)" 
                        [name]="s ? 'star' : 'star-outline'"
                        [class.filled]="s"></ion-icon>
              <span>{{ paquete.calificacion }}/5</span>
            </div>
          </div>

          <p class="description">{{ paquete.descripcion }}</p>

          <!-- Info rápida -->
          <div class="quick-info">
            <div class="info-chip" *ngIf="paquete.duracion">
              <ion-icon name="time-outline"></ion-icon>
              <span>{{ paquete.duracion }}</span>
            </div>
            <div class="info-chip" *ngIf="paquete.destinos">
              <ion-icon name="location-outline"></ion-icon>
              <span>{{ paquete.destinos }}</span>
            </div>
            <div class="info-chip" *ngIf="paquete.salida">
              <ion-icon name="calendar-outline"></ion-icon>
              <span>{{ paquete.salida }}</span>
            </div>
          </div>

          <!-- Lo que incluye -->
          <div class="includes-section" *ngIf="paquete.incluye">
            <h3><ion-icon name="checkmark-circle-outline"></ion-icon> El paquete incluye</h3>
            <div class="includes-grid">
              <div class="include-item" *ngFor="let item of getIncluidos()">
                <ion-icon [name]="getIncludeIcon(item)"></ion-icon>
                <span>{{ item }}</span>
              </div>
            </div>
          </div>

          <!-- Destinos incluidos -->
          <div class="destinos-section" *ngIf="paquete.destinos">
            <h3><ion-icon name="airplane-outline"></ion-icon> Destinos del paquete</h3>
            <p>{{ paquete.destinos }}</p>
          </div>

          <!-- Información adicional -->
          <div class="additional-info">
            <div class="info-row">
              <ion-icon name="shield-checkmark-outline"></ion-icon>
              <span>Cancelación gratuita hasta 48h antes</span>
            </div>
            <div class="info-row">
              <ion-icon name="people-outline"></ion-icon>
              <span>Grupos pequeños (máx. 15 personas)</span>
            </div>
          </div>

          <!-- Botones de acción -->
          <div class="action-buttons">
            <div class="total-price">
              <span class="label">Precio total</span>
              <span class="amount">\${{ paquete.precio }} USD</span>
            </div>
            <ion-button expand="block" class="tg-btn-primary" (click)="reservar()">
              <ion-icon name="calendar-outline" slot="start"></ion-icon>
              Reservar Ahora
            </ion-button>
            <ion-button expand="block" fill="outline" (click)="contactar()">
              Solicitar Información
            </ion-button>
          </div>
        </div>
      </div>
    </ion-content>
  `,
  styles: [`
    .modal-content {
      padding-bottom: 40px;
    }

    .image-container {
      position: relative;
      width: 100%;
      height: 260px;
      border-radius: 20px;
      overflow: hidden;
      margin-bottom: 24px;

      img {
        width: 100%;
        height: 100%;
        object-fit: cover;
      }

      .price-badge {
        position: absolute;
        bottom: 12px;
        right: 12px;
        background: linear-gradient(135deg, #27ae60 0%, #2ecc71 100%);
        padding: 10px 18px;
        border-radius: 14px;
        color: #fff;
        display: flex;
        align-items: baseline;
        gap: 4px;
        box-shadow: 0 4px 15px rgba(39, 174, 96, 0.4);

        .price {
          font-size: 24px;
          font-weight: 700;
        }

        .currency {
          font-size: 12px;
          opacity: 0.9;
        }
      }

      .type-badge {
        position: absolute;
        top: 12px;
        left: 12px;
        background: rgba(243, 156, 18, 0.95);
        color: #fff;
        padding: 6px 14px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 600;
        text-transform: uppercase;
      }
    }

    .paquete-info {
      .paquete-header {
        margin-bottom: 16px;

        h1 {
          font-size: 26px;
          font-weight: 700;
          color: #2c3e50;
          margin: 0 0 8px 0;
        }

        .rating {
          display: flex;
          align-items: center;
          gap: 4px;

          ion-icon {
            font-size: 18px;
            color: #ddd;

            &.filled {
              color: #f39c12;
            }
          }

          span {
            margin-left: 8px;
            font-size: 14px;
            color: #7f8c8d;
            font-weight: 500;
          }
        }
      }

      .description {
        font-size: 16px;
        color: #7f8c8d;
        line-height: 1.7;
        margin-bottom: 20px;
      }

      .quick-info {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        margin-bottom: 24px;

        .info-chip {
          display: flex;
          align-items: center;
          gap: 6px;
          background: #f8f9fa;
          padding: 10px 14px;
          border-radius: 10px;

          ion-icon {
            font-size: 18px;
            color: #1a5276;
          }

          span {
            font-size: 13px;
            font-weight: 500;
            color: #2c3e50;
          }
        }
      }

      .includes-section {
        margin-bottom: 24px;

        h3 {
          font-size: 16px;
          font-weight: 600;
          color: #2c3e50;
          margin: 0 0 16px 0;
          display: flex;
          align-items: center;
          gap: 8px;

          ion-icon {
            color: #27ae60;
          }
        }

        .includes-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 12px;

          .include-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 12px;
            background: linear-gradient(135deg, #f8f9fa 0%, #fff 100%);
            border-radius: 12px;
            border: 1px solid #eee;

            ion-icon {
              font-size: 22px;
              color: #1a5276;
            }

            span {
              font-size: 13px;
              color: #2c3e50;
              font-weight: 500;
            }
          }
        }
      }

      .destinos-section {
        background: linear-gradient(135deg, #1a5276 0%, #2980b9 100%);
        padding: 20px;
        border-radius: 16px;
        margin-bottom: 24px;

        h3 {
          color: #fff;
          font-size: 16px;
          margin: 0 0 12px 0;
          display: flex;
          align-items: center;
          gap: 8px;

          ion-icon {
            color: #f39c12;
          }
        }

        p {
          color: rgba(255, 255, 255, 0.9);
          font-size: 14px;
          line-height: 1.6;
          margin: 0;
        }
      }

      .additional-info {
        margin-bottom: 24px;

        .info-row {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 12px 0;
          border-bottom: 1px solid #eee;

          &:last-child {
            border-bottom: none;
          }

          ion-icon {
            font-size: 22px;
            color: #27ae60;
          }

          span {
            font-size: 14px;
            color: #7f8c8d;
          }
        }
      }

      .action-buttons {
        .total-price {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 16px;
          background: #f8f9fa;
          border-radius: 14px;
          margin-bottom: 16px;

          .label {
            font-size: 14px;
            color: #7f8c8d;
          }

          .amount {
            font-size: 28px;
            font-weight: 700;
            color: #27ae60;
          }
        }

        ion-button {
          --border-radius: 12px;
          height: 50px;
          font-weight: 600;
          margin-bottom: 10px;
        }

        .tg-btn-primary {
          --background: linear-gradient(135deg, #f39c12 0%, #e67e22 100%);
          --color: #fff;
        }
      }
    }
  `],
  standalone: true,
  imports: [
    CommonModule,
    IonHeader,
    IonToolbar,
    IonTitle,
    IonContent,
    IonButton,
    IonIcon,
    IonButtons,
    IonChip,
    IonLabel,
    IonBadge
  ],
})
export class PaqueteDetailModal implements OnInit {
  @Input() paquete!: Paquete;
  
  private modalController = inject(ModalController);
  private toastController = inject(ToastController);

  constructor() {
    addIcons({
      closeOutline,
      airplaneOutline,
      calendarOutline,
      checkmarkCircleOutline,
      starOutline,
      star,
      locationOutline,
      timeOutline,
      walletOutline,
      peopleOutline,
      bedOutline,
      restaurantOutline,
      busOutline,
      cameraOutline,
      shieldCheckmarkOutline
    });
  }

  ngOnInit() {}

  dismiss() {
    this.modalController.dismiss();
  }

  getStars(rating: number): boolean[] {
    const stars = [];
    for (let i = 1; i <= 5; i++) {
      stars.push(i <= rating);
    }
    return stars;
  }

  getIncluidos(): string[] {
    if (!this.paquete.incluye) return [];
    return this.paquete.incluye.split(',').map(item => item.trim());
  }

  getIncludeIcon(item: string): string {
    const lower = item.toLowerCase();
    if (lower.includes('hotel') || lower.includes('alojamiento')) return 'bed-outline';
    if (lower.includes('vuelo') || lower.includes('avion')) return 'airplane-outline';
    if (lower.includes('comida') || lower.includes('desayuno') || lower.includes('cena')) return 'restaurant-outline';
    if (lower.includes('transporte') || lower.includes('traslado')) return 'bus-outline';
    if (lower.includes('tour') || lower.includes('excursion') || lower.includes('visita')) return 'camera-outline';
    if (lower.includes('seguro')) return 'shield-checkmark-outline';
    return 'checkmark-circle-outline';
  }

  reservar() {
    this.showToast('Redirigiendo a reservas...');
    this.dismiss();
  }

  contactar() {
    this.showToast('Abriendo formulario de contacto...');
    this.dismiss();
  }

  async showToast(message: string) {
    const toast = await this.toastController.create({
      message,
      duration: 2000,
      position: 'bottom'
    });
    await toast.present();
  }
}
