import { Injectable, inject } from '@angular/core';
import { 
  Firestore, 
  collection, 
  collectionData, 
  doc, 
  addDoc, 
  updateDoc, 
  deleteDoc 
} from '@angular/fire/firestore';
import { Observable } from 'rxjs';
import { Paquete } from '../models/models';

@Injectable({
  providedIn: 'root'
})
export class PaquetesService {
  private firestore = inject(Firestore);
  private collectionName = 'paquetes';

  // Obtener todos los paquetes
  getPaquetes(): Observable<Paquete[]> {
    const paquetesRef = collection(this.firestore, this.collectionName);
    return collectionData(paquetesRef, { idField: 'id' }) as Observable<Paquete[]>;
  }

  // Agregar un paquete
  async addPaquete(paquete: Paquete): Promise<void> {
    const paquetesRef = collection(this.firestore, this.collectionName);
    await addDoc(paquetesRef, paquete);
  }

  // Actualizar un paquete
  async updatePaquete(id: string, paquete: Partial<Paquete>): Promise<void> {
    const paqueteRef = doc(this.firestore, this.collectionName, id);
    await updateDoc(paqueteRef, paquete);
  }

  // Eliminar un paquete
  async deletePaquete(id: string): Promise<void> {
    const paqueteRef = doc(this.firestore, this.collectionName, id);
    await deleteDoc(paqueteRef);
  }
}
