export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyDTFPZBFTVUXuT6xToznKu18h5WDvuAquc",
    authDomain: "travelgo-6bb97.firebaseapp.com",
    projectId: "travelgo-6bb97",
    storageBucket: "travelgo-6bb97.firebasestorage.app",
    messagingSenderId: "1002048016788",
    appId: "1:1002048016788:web:0cfd811a28b4537ce07f81",
    measurementId: "G-GPVDWPG9G9"
  }
};
