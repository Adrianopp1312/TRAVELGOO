import { Component } from '@angular/core';
import { 
  IonTabs, 
  IonTabBar, 
  IonTabButton, 
  IonIcon, 
  IonLabel 
} from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import { 
  homeOutline, 
  home,
  compassOutline, 
  compass,
  briefcaseOutline, 
  briefcase,
  heartOutline, 
  heart,
  chatbubblesOutline,
  chatbubbles
} from 'ionicons/icons';

@Component({
  selector: 'app-tabs',
  template: `
    <ion-tabs>
      <ion-tab-bar slot="bottom">
        <ion-tab-button tab="home">
          <ion-icon name="home-outline"></ion-icon>
          <ion-label>Inicio</ion-label>
        </ion-tab-button>

        <ion-tab-button tab="destinos">
          <ion-icon name="compass-outline"></ion-icon>
          <ion-label>Destinos</ion-label>
        </ion-tab-button>

        <ion-tab-button tab="paquetes">
          <ion-icon name="briefcase-outline"></ion-icon>
          <ion-label>Paquetes</ion-label>
        </ion-tab-button>

        <ion-tab-button tab="favoritos">
          <ion-icon name="heart-outline"></ion-icon>
          <ion-label>Favoritos</ion-label>
        </ion-tab-button>

        <ion-tab-button tab="contacto">
          <ion-icon name="chatbubbles-outline"></ion-icon>
          <ion-label>Contacto</ion-label>
        </ion-tab-button>
      </ion-tab-bar>
    </ion-tabs>
  `,
  styles: [`
    ion-tab-bar {
      --background: #ffffff;
      border-top: none;
      box-shadow: 0 -4px 20px rgba(0, 0, 0, 0.08);
      padding: 8px 0 12px;
      border-radius: 24px 24px 0 0;
    }

    ion-tab-button {
      --color: #95a5a6;
      --color-selected: #1a5276;
      
      ion-icon {
        font-size: 22px;
        margin-bottom: 4px;
      }

      ion-label {
        font-size: 10px;
        font-weight: 500;
        letter-spacing: 0.3px;
      }

      &.tab-selected {
        ion-icon {
          color: #1a5276;
        }
        ion-label {
          color: #1a5276;
        }
      }
    }
  `],
  standalone: true,
  imports: [IonTabs, IonTabBar, IonTabButton, IonIcon, IonLabel],
})
export class TabsPage {
  constructor() {
    addIcons({ 
      homeOutline, 
      home,
      compassOutline, 
      compass,
      briefcaseOutline, 
      briefcase,
      heartOutline, 
      heart,
      chatbubblesOutline,
      chatbubbles
    });
  }
}
