import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonCardSubtitle,
  IonCardContent,
  IonButton,
  IonIcon,
  IonList,
  IonItem,
  IonLabel,
  IonItemSliding,
  IonItemOptions,
  IonItemOption,
  IonAvatar,
  IonSkeletonText,
  IonRefresher,
  IonRefresherContent,
  AlertController,
  ToastController
} from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import {
  heartOutline,
  heart,
  trashOutline,
  locationOutline,
  airplaneOutline,
  refreshOutline,
  sadOutline
} from 'ionicons/icons';
import { FavoritosService } from '../../services/favoritos.service';
import { DestinosService } from '../../services/destinos.service';
import { Favorito, Destino } from '../../models/models';
import { Observable, map, switchMap, of, combineLatest } from 'rxjs';

interface FavoritoConDestino extends Favorito {
  destinoData?: Destino;
}

@Component({
  selector: 'app-favoritos',
  template: `
    <ion-header class="tg-header">
      <ion-toolbar>
        <ion-title>
          <ion-icon name="heart"></ion-icon>
          Mis Favoritos
        </ion-title>
      </ion-toolbar>
    </ion-header>

    <ion-content [fullscreen]="true">
      <ion-refresher slot="fixed" (ionRefresh)="doRefresh($event)">
        <ion-refresher-content pullingIcon="refresh-outline" refreshingSpinner="circles">
        </ion-refresher-content>
      </ion-refresher>

      <div class="favoritos-container tg-fade-in">
        <div class="favoritos-header">
          <div class="heart-icon-bg">
            <ion-icon name="heart"></ion-icon>
          </div>
          <h2>Tus Destinos Favoritos</h2>
          <p>Desliza hacia la izquierda para eliminar</p>
        </div>

        @if (favoritosConDestino$ | async; as favoritos) {
          @if (favoritos.length > 0) {
            <ion-list lines="none" class="favorites-list">
              @for (fav of favoritos; track fav.id) {
                <ion-item-sliding>
                  <ion-item class="favorite-item">
                    <ion-avatar slot="start" class="destination-avatar">
                      <img [src]="fav.destinoData?.imagen || 'https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=800'" 
                           [alt]="fav.destino"
                           onerror="this.src='https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=800'"/>
                    </ion-avatar>
                    <ion-label>
                      <h2>{{ fav.destino }}</h2>
                      <p>
                        <ion-icon name="location-outline"></ion-icon>
                        {{ fav.destinoData?.pais || 'Destino' }}
                      </p>
                      <p class="description">{{ fav.destinoData?.descripcion || '' }}</p>
                    </ion-label>
                    <ion-icon name="heart" class="heart-indicator" slot="end"></ion-icon>
                  </ion-item>

                  <ion-item-options side="end">
                    <ion-item-option color="danger" (click)="removeFavorite(fav)">
                      <ion-icon name="trash-outline" slot="icon-only"></ion-icon>
                    </ion-item-option>
                  </ion-item-options>
                </ion-item-sliding>
              }
            </ion-list>

            <div class="favorites-count">
              <ion-icon name="airplane-outline"></ion-icon>
              <span>{{ favoritos.length }} destino(s) en tu lista</span>
            </div>
          } @else {
            <div class="tg-empty-state">
              <ion-icon name="sad-outline"></ion-icon>
              <h3>No tienes favoritos aún</h3>
              <p>Explora destinos y agrega tus favoritos tocando el corazón</p>
              <ion-button class="tg-btn-primary" routerLink="/tabs/destinos">
                Explorar Destinos
              </ion-button>
            </div>
          }
        } @else {
          <!-- Loading state -->
          <ion-list lines="none" class="favorites-list">
            @for (i of [1,2,3]; track i) {
              <ion-item class="favorite-item">
                <ion-avatar slot="start">
                  <ion-skeleton-text [animated]="true"></ion-skeleton-text>
                </ion-avatar>
                <ion-label>
                  <ion-skeleton-text [animated]="true" style="width: 60%;"></ion-skeleton-text>
                  <ion-skeleton-text [animated]="true" style="width: 40%;"></ion-skeleton-text>
                </ion-label>
              </ion-item>
            }
          </ion-list>
        }
      </div>
    </ion-content>
  `,
  styles: [`
    ion-toolbar ion-title {
      display: flex;
      align-items: center;
      gap: 8px;
      
      ion-icon {
        font-size: 22px;
        color: #e74c3c;
      }
    }

    .favoritos-container {
      padding: 20px 16px;
    }

    .favoritos-header {
      text-align: center;
      margin-bottom: 32px;

      .heart-icon-bg {
        width: 80px;
        height: 80px;
        background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 20px;
        box-shadow: 0 8px 25px rgba(231, 76, 60, 0.35);

        ion-icon {
          font-size: 40px;
          color: white;
        }
      }

      h2 {
        font-size: 24px;
        font-weight: 700;
        color: #2c3e50;
        margin-bottom: 8px;
      }

      p {
        font-size: 14px;
        color: #7f8c8d;
      }
    }

    .favorites-list {
      background: transparent;

      .favorite-item {
        --background: white;
        --padding-start: 16px;
        --padding-end: 16px;
        --padding-top: 12px;
        --padding-bottom: 12px;
        margin-bottom: 12px;
        border-radius: 16px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);

        .destination-avatar {
          width: 70px;
          height: 70px;
          border-radius: 14px;
          overflow: hidden;

          img {
            width: 100%;
            height: 100%;
            object-fit: cover;
          }
        }

        ion-label {
          margin-left: 12px;

          h2 {
            font-size: 18px;
            font-weight: 600;
            color: #2c3e50;
            margin-bottom: 4px;
          }

          p {
            font-size: 13px;
            color: #7f8c8d;
            display: flex;
            align-items: center;
            gap: 4px;

            &.description {
              margin-top: 4px;
              font-style: italic;
            }
          }
        }

        .heart-indicator {
          font-size: 24px;
          color: #e74c3c;
        }
      }
    }

    ion-item-option {
      --border-radius: 16px;
      margin: 12px 8px 12px 0;
    }

    .favorites-count {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      padding: 20px;
      background: linear-gradient(135deg, rgba(26, 82, 118, 0.1) 0%, rgba(41, 128, 185, 0.1) 100%);
      border-radius: 16px;
      margin-top: 24px;

      ion-icon {
        font-size: 24px;
        color: #1a5276;
      }

      span {
        font-size: 14px;
        font-weight: 500;
        color: #1a5276;
      }
    }

    .tg-empty-state {
      ion-button {
        margin-top: 20px;
      }
    }
  `],
  standalone: true,
  imports: [
    CommonModule,
    IonHeader,
    IonToolbar,
    IonTitle,
    IonContent,
    IonCard,
    IonCardHeader,
    IonCardTitle,
    IonCardSubtitle,
    IonCardContent,
    IonButton,
    IonIcon,
    IonList,
    IonItem,
    IonLabel,
    IonItemSliding,
    IonItemOptions,
    IonItemOption,
    IonAvatar,
    IonSkeletonText,
    IonRefresher,
    IonRefresherContent
  ],
})
export class FavoritosPage implements OnInit {
  private favoritosService = inject(FavoritosService);
  private destinosService = inject(DestinosService);
  private alertController = inject(AlertController);
  private toastController = inject(ToastController);

  favoritosConDestino$!: Observable<FavoritoConDestino[]>;

  constructor() {
    addIcons({
      heartOutline,
      heart,
      trashOutline,
      locationOutline,
      airplaneOutline,
      refreshOutline,
      sadOutline
    });
  }

  ngOnInit() {
    this.loadFavoritos();
  }

  loadFavoritos() {
    this.favoritosConDestino$ = combineLatest([
      this.favoritosService.getFavoritos(),
      this.destinosService.getDestinos()
    ]).pipe(
      map(([favoritos, destinos]) => {
        return favoritos.map(fav => ({
          ...fav,
          destinoData: destinos.find(d => d.nombre === fav.destino)
        }));
      })
    );
  }

  async removeFavorite(favorito: FavoritoConDestino) {
    const alert = await this.alertController.create({
      header: 'Eliminar de favoritos',
      message: `¿Deseas eliminar ${favorito.destino} de tus favoritos?`,
      buttons: [
        {
          text: 'Cancelar',
          role: 'cancel'
        },
        {
          text: 'Eliminar',
          role: 'destructive',
          handler: async () => {
            if (favorito.id) {
              await this.favoritosService.deleteFavorito(favorito.id);
              this.showToast('Eliminado de favoritos');
              this.loadFavoritos();
            }
          }
        }
      ]
    });
    await alert.present();
  }

  async doRefresh(event: any) {
    this.loadFavoritos();
    setTimeout(() => {
      event.target.complete();
    }, 1000);
  }

  async showToast(message: string) {
    const toast = await this.toastController.create({
      message,
      duration: 2000,
      position: 'bottom',
      icon: 'heart-outline'
    });
    await toast.present();
  }
}
